public class Main {
	public static void main(String[] args) {
		int arr[] = {5, 2, 1, 2, 4, 5};
		int cnt = 0;

		for (int i = 0; i < arr.length; i++) {
			while (arr[i] != i + 1 && arr[i] > 0 && arr[i] != arr[arr[i] - 1]) {
				cnt++;
				int temp = arr[i];
				if (temp != arr[temp - 1]) { // Check for duplicates
					arr[i] = arr[temp - 1];
					arr[temp - 1] = temp;
				}
			}
		}

		System.out.println(cnt);

		for (int e : arr) {
			System.out.print(e + " ");
		}
		System.out.println();

		// Find the smallest missing number
		int smallestMissing = -1;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] != i + 1) {
				smallestMissing = i + 1;
				break;
			}
		}

		if (smallestMissing == -1) {
			smallestMissing = arr.length + 1;
		}
		System.out.println("Smallest Missing Number: " + smallestMissing);
	}
}