class bankaccount {
    
	int accountNumber;
	String name;
	String branch;
	double balance = 0.0;
	static String bank = "SBI"; //to make commom bank for all 

//.constructor:- ALL CALLED WHILE INITIALIZING AND CALLING A CLASS..
	bankaccount(int accountNumber, String name, String branch) {
		this.accountNumber = accountNumber;
		this.name = name;
		this.branch = branch;
	}
	
	void print(){
	    System.out.println(this.accountNumber + " " + this.name + " " + 
	                        this.branch + " " + this.bank);
	}
}

public class Main
{

	public static void main(String[] args) {

		bankaccount obj = new bankaccount(1, "Aayush", "LPU");
		obj.print();
		System.out.println(bankaccount.bank); //calling static variable with clas name
	}
}
