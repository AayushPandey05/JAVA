import java.util.*;

class Employee {
	int id = 290609;
	String CompanyName = "GOOGLE";
	String designation = "Analyst";
	String department = "Data Security and Consultant";

	void print() {
		System.out.println(id);
		System.out.println(CompanyName);
		System.out.println(designation);
		System.out.println(department);
	}

	void updateDesignation(String designation) {
		this.designation = designation;
	}
	
	void updateDepartment(String department){
	    this.department = department;
	}

}

public class Main {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);

		Employee obj = new Employee();

		obj.updateDesignation("Senior Solution Engineer"); 
		obj.updateDepartment("Development");
		obj.print(); 
	}
}