import java.util.* ;
import java.io.*; 
public class Solution {
	public static int[] countEvenOdd(int[] arr, int n) {
		// Write your code here.
		int odd = 0;
		int even = 0;

		for(int i = 0; i < n; i++){
			int count = 0;

			for(int j = 0; j < n; j++){
				if(arr[i] == arr[j]) {
					count++;
				}
			}

			boolean counted = false;
			for(int j = 0; j < i; j++) {
				if(arr[i] == arr[j]){
					counted = true;
					break;
				}
			}

			if(!counted){
				if(count % 2 == 0){
					even++;
				}
				else{
					odd++;
				}
			}
		}

		return new int[]{odd, even};
	}
}
