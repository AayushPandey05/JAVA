import java.util.Scanner;

class BankAccount {
	int id;
	String name;
	String bankName;
	String branch;
	double balance;

	void inputDetails(int id, String name, String bankName, String branch, double balance) {
		this.id = id;
		this.name = name;
		this.bankName = bankName;
		this.branch = branch;
		this.balance = balance;
	}

	void print() {
		System.out.println("ID: " + id);
		System.out.println("NAME: " + name);
		System.out.println("BankName: " + bankName);
		System.out.println("Branch: " + branch);
		System.out.println("Balance: Rs. " + balance);
	}

	void updateBranch(String newBranch) {
		this.branch = newBranch;
	}
}

public class Main {
	public static void main(String[] args) {
		BankAccount obj = new BankAccount();

		obj.inputDetails(12301150, "Aayush Pandey", "SBI", "KOLKATA", 30000.11);
		obj.updateBranch("Punjab");
		obj.print();
	}
}