class SecondsToTime {
    private int hours;
    private int minutes;
    private int seconds;

    // Constructor that takes total seconds and converts it to hh:mm:ss
    public SecondsToTime(int totalSeconds) {
        // Calculate hours, minutes, and seconds
        this.hours = totalSeconds / 3600; // 1 hour = 3600 seconds
        totalSeconds %= 3600; // Remaining seconds after extracting hours
        this.minutes = totalSeconds / 60; // 1 minute = 60 seconds
        this.seconds = totalSeconds % 60; // Remaining seconds after extracting minutes
    }

    // Method to display the time in hh:mm:ss format
    public void displayTime() {
        System.out.printf("%02d:%02d:%02d%n", hours, minutes, seconds);
    }
}

// Main class provided
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalSeconds = scanner.nextInt();
        scanner.close();

        SecondsToTime timeConverter = new SecondsToTime(totalSeconds);
        timeConverter.displayTime();
    }
}