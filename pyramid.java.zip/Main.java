// import java.util.Scanner;

// public class Main {
//   public static void main(String[] args) {

//     Scanner scn = new Scanner(System.in);

//     int n = scn.nextInt();
    
//     for(int i=0;i<n;i++){
//         for(int j=0;j<(n - i - 1);j++){
//             System.out.print(" ");
//         }
        
//         for(int j = 0; j < 2 * i + 1; j++){
//             System.out.print("*");
//         }
        
//         for(int j=1;j<n-i;j++){
//             System.out.print(" ");
//         }
//         System.out.println();
//     }
//   }
// }

///DIAMOND
// Online Free Java compiler to run Java program online
public class Main {
public static void main(String[] args) {

int n = 3;

//pyramid -> part 1
for(int i =1; i<=n; i++){

//spaces
for(int j=1; j<=n-i; j++){
System.out.print(" ");
}

//stars
for(int j=1; j<=2*i-1; j++)
System.out.print("*");

System.out.println();
}

//part 2 --> reversed pyramid
for(int i=n-1; i>=1; i--){

//spaces
for(int j=1; j<=n-i; j++){
System.out.print(" ");
}

//stars
for(int j=1; j<=2*i-1; j++)
System.out.print("*");

System.out.println();
}

}
}


