import java.util.* ;
import java.io.*; 
public class Solution {
	public static void rotate(ArrayList<Integer> arr, int n) {
		// Write your code here.
		if(n <= 1) {
			return;
		}

		int last = arr.get(n - 1); //to get the last element

		for(int i = n - 1; i > 0; i--) {
			arr.set(i, arr.get(i - 1));  //shift all elem to one pos to right
		}

		arr.set(0, last);
	}
}