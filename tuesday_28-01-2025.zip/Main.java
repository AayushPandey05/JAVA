import java.util.*;

// public class Main{
//     public static void main(String[] args) {
//         Scanner scn = new Scanner(System.in);
//         int n = scn.nextInt();
//         int st;
//         if(n % 2 == 0){
//             st = n - 1;
//         }
//         else{
//             st = n;
//         }
// 		for(int i = st ; i > 0; i -=2){
// 		    System.out.print(i + " ");
// 		}
// 	}
// }



//////////////////////////////////////////



///using while loop
// import java.util.Scanner;

// public class Main {
//     public static void main(String[] args) {
//         Scanner scanner = new Scanner(System.in);
//         int n = scanner.nextInt();
        
//         int powerOfTwo = 1;

//         while (powerOfTwo <= n) {
//             System.out.print(powerOfTwo + " ");
//             powerOfTwo *= 2; //ye powerOfTwo ko update krega
//         }
//     }
// }



////!/........Printing Grid Patter of "1"......

// public class Main{
//     public static void main(String[] args){
//         for(int i=0 ; i<3;i++){
//             for(int j=0;j<3;j++){
//                 System.out.print("1 ");
//             }
//             System.out.print("\n");
//         }
//     }
// }



///////////////////////////////////////////////////////

// public class Main {
//     public static void main(String[] args) {
//         int rows = 4;

//         for (int i = 1; i <= rows; i++) {
//             for (int j = 1; j <= i; j++) {
//                 System.out.print(j + " ");
//             }
//             System.out.println();
//         }
//     }
// }



///////////////////////////////////////////////////////////

// public class Pattern {
//     public static void main(String[] args) {
//         Scanner scn = new Scanner(System.in);
        
//         System.out.print("Enter Number of Rows: ");
//         int num = scn.nextInt();
        
//         for (int i = 1; i <= num; i++) {
//             for (int j = 1; j <= (num - i); j++) {
//                 System.out.print(" ");
//             }
//             for (int j = i; j >= 1; j--) {
//                 System.out.print(j);
//             }
//             System.out.println();
//         }
//     }
// }


///////////////////////////////////////////////////////////////

public class Main {
    public static void main(String[] args) {
        int n = 4;
        
        //for spaces..
        for(int i = 1; i <= n; i++){
            for(int j= 1; j<= (n - i); j++){
                System.out.print(" ");
            }
            
            //for numbers...
            for(int j = i; j >= 1; j--){
                System.out.print(j);
            }
            
            System.out.print("\n");
        }
    }
}

////