import java.util.Scanner;

class CarsManufacturer{
    static String Brand = "McLeran";
    String Model;
    String Colour;
    String ownerName;
    int Platenumber;
    static int speed = 340;

    CarsManufacturer(String Model, String Colour, String ownerName, int Platenumber) {
        this.Model = Model;
        this.Colour = Colour;
        this.ownerName = ownerName;
        this.Platenumber = Platenumber;
    }
    void print() {
        System.out.println("BRAND: " + Brand);
        System.out.println("Model: " + Model);
        System.out.println("Colour: " + Colour);
        System.out.println("ownerName: " + ownerName);
        System.out.println("Platenumber: " + Platenumber);
        System.out.println("Speed: " + speed + " Km/Hr");
    }
}

public class Main {
    public static void main(String[] args) {
        
        CarsManufacturer obj = new CarsManufacturer("McLaren 720S", "Red", "Aayush Pandey", 2005);
        obj.print();
        
        System.out.println(CarsManufacturer.Brand);
        System.out.println(CarsManufacturer.speed + " Km/Hr");
    }
}