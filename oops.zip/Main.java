import java.util.*;
class A {
	int a = 10;

	void print() {
		System.out.print(a);
	}

	void update(int a) {
		this.a = a; //this is a key pointing to the variable a inside fun update
        
	}
}

public class Main
{

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);

		A obj = new A();

		obj.update(20);
		obj.print();
	}
}
