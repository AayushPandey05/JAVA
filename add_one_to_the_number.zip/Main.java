import java.util.* ;
import java.io.*; 
public class Solution
{
    public static ArrayList<Integer> addOneToNumber(ArrayList<Integer> arr)
        {
            // Write your code here.
            int n = arr.size();
            int carry = 1;

            for(int i = n - 1; i >= 0; i--) {
                int sum = arr.get(i) + carry;
                arr.set(i, sum % 10); //update the current digit..

                carry = sum / 10;
            }

            //if there is still a carry left, we need to add a new digit at the beginning
            if(carry > 0){
                arr.add(0, carry); //add carry at the beginning of the list
            }

            while(arr.size() > 1 && arr.get(0) == 0) {
                arr.remove(0);
            }
            return arr;

        }
}
